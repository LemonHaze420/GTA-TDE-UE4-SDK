﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct RadioWheelColors.RadioWheelColors
// 0x00F0
struct FRadioWheelColors
{
	struct FSlateColor                                 NormalBackgroundColor_2_238B11E04ACB5B5719D06CA860C12A3C;  // 0x0000(0x0028) (Edit, BlueprintVisible)
	struct FSlateColor                                 SelectedBackgroundColor_4_10F2BABC475AE623F69FA691D74D8566; // 0x0028(0x0028) (Edit, BlueprintVisible)
	struct FSlateColor                                 NormalRingBackgroundColor_9_4327A0DA4948BD70B7BF61A14FDE4817; // 0x0050(0x0028) (Edit, BlueprintVisible)
	struct FSlateColor                                 SelectedRingBackgroundColor_10_2D0F785E4645FBC63950329649CEA436; // 0x0078(0x0028) (Edit, BlueprintVisible)
	struct FSlateColor                                 NormalTintColor_11_B6E6272B46BEEAEAB56ABDA1D026C5D7;       // 0x00A0(0x0028) (Edit, BlueprintVisible)
	struct FSlateColor                                 SelectedTintColor_12_F5C68A7A4414489FA65DA18B49DA61D0;     // 0x00C8(0x0028) (Edit, BlueprintVisible)

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
