﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ButtonStateEnum.ButtonStateEnum
enum class ButtonStateEnum_EButtonStateEnum : uint8_t
{
	ButtonStateEnum__NewEnumerator4 = 0,
	ButtonStateEnum__NewEnumerator0 = 1,
	ButtonStateEnum__NewEnumerator1 = 2,
	ButtonStateEnum__NewEnumerator2 = 3,
	ButtonStateEnum__NewEnumerator3 = 4,
	ButtonStateEnum__ButtonStateEnum_MAX = 5,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
