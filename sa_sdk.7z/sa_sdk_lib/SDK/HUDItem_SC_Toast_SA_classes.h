﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// WidgetBlueprintGeneratedClass HUDItem_SC_Toast_SA.HUDItem_SC_Toast_SA_C
// 0x0000 (FullSize[0x0338] - InheritedSize[0x0338])
class UHUDItem_SC_Toast_SA_C : public UHUDItem_SC_ToastBase_C
{
public:


	static UClass* StaticClass()
	{
		static UClass* ptr = UObject::FindClass("WidgetBlueprintGeneratedClass HUDItem_SC_Toast_SA.HUDItem_SC_Toast_SA_C");
		return ptr;
	}



};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
