﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Script Structs
//---------------------------------------------------------------------------

// UserDefinedStruct JoinedButtonTemplateModifiers.JoinedButtonTemplateModifiers
// 0x0360
struct FJoinedButtonTemplateModifiers
{
	struct FText                                       ButtonTextValue_9_9FE5D8904013DDDA10120BBC559DE894;        // 0x0000(0x0018) (Edit, BlueprintVisible)
	struct FButtonTemplateModifiers                    NormalTemplate_4_D481CDC24C95D1DA54CD16B5E3926A46;         // 0x0018(0x0118) (Edit, BlueprintVisible, HasGetValueTypeHash)
	struct FButtonTemplateModifiers                    HoveredTemplate_6_EDFC4F3240BC68BF7F32079C51EDDE06;        // 0x0130(0x0118) (Edit, BlueprintVisible, HasGetValueTypeHash)
	struct FButtonTemplateModifiers                    SelectedTemplate_8_1F80D9A94B64D7C09694628E03F1C935;       // 0x0248(0x0118) (Edit, BlueprintVisible, HasGetValueTypeHash)

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
