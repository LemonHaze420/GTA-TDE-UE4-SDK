﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Parameters
//---------------------------------------------------------------------------

// Function UI_SC_Achivements.UI_SC_Achivements_C.TakeFocus
struct UUI_SC_Achivements_C_TakeFocus_Params
{
	bool                                               ReturnValue;                                               // 0x0000(0x0001)  (Parm, OutParm, ZeroConstructor, ReturnParm, IsPlainOldData, NoDestructor)
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.WrapNavigation
struct UUI_SC_Achivements_C_WrapNavigation_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.SetupNavigation
struct UUI_SC_Achivements_C_SetupNavigation_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.RefreshList
struct UUI_SC_Achivements_C_RefreshList_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.CheckCreation
struct UUI_SC_Achivements_C_CheckCreation_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.CreateScrollingListItems
struct UUI_SC_Achivements_C_CreateScrollingListItems_Params
{
	bool                                               DEBUG_ALL_ITEMS;                                           // 0x0000(0x0001)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.PreConstruct
struct UUI_SC_Achivements_C_PreConstruct_Params
{
	bool                                               IsDesignTime;                                              // 0x0000(0x0001)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor)
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.Construct
struct UUI_SC_Achivements_C_Construct_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.Tick
struct UUI_SC_Achivements_C_Tick_Params
{
	struct FGeometry                                   MyGeometry;                                                // 0x0000(0x0038)  (BlueprintVisible, BlueprintReadOnly, Parm, IsPlainOldData, NoDestructor)
	float                                              InDeltaTime;                                               // 0x0038(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.OnSynchronizeProperties
struct UUI_SC_Achivements_C_OnSynchronizeProperties_Params
{
};

// Function UI_SC_Achivements.UI_SC_Achivements_C.ExecuteUbergraph_UI_SC_Achivements
struct UUI_SC_Achivements_C_ExecuteUbergraph_UI_SC_Achivements_Params
{
	int                                                EntryPoint;                                                // 0x0000(0x0004)  (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData, NoDestructor, HasGetValueTypeHash)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
