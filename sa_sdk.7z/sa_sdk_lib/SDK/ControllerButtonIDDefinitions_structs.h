﻿#pragma once

// Name: SanAndreas, Version: 1.0.0


/*!!DEFINE!!*/

/*!!HELPER_DEF!!*/

/*!!HELPER_INC!!*/

#ifdef _MSC_VER
	#pragma pack(push, 0x01)
#endif

namespace CG
{
//---------------------------------------------------------------------------
// Enums
//---------------------------------------------------------------------------

// UserDefinedEnum ControllerButtonIDDefinitions.ControllerButtonIDDefinitions
enum class ControllerButtonIDDefinitions_EControllerButtonIDDefinitions : uint8_t
{
	ControllerButtonIDDefinitions__NewEnumerator0 = 0,
	ControllerButtonIDDefinitions__NewEnumerator1 = 1,
	ControllerButtonIDDefinitions__NewEnumerator2 = 2,
	ControllerButtonIDDefinitions__NewEnumerator3 = 3,
	ControllerButtonIDDefinitions__NewEnumerator4 = 4,
	ControllerButtonIDDefinitions__NewEnumerator5 = 5,
	ControllerButtonIDDefinitions__NewEnumerator6 = 6,
	ControllerButtonIDDefinitions__NewEnumerator7 = 7,
	ControllerButtonIDDefinitions__NewEnumerator8 = 8,
	ControllerButtonIDDefinitions__NewEnumerator9 = 9,
	ControllerButtonIDDefinitions__NewEnumerator10 = 10,
	ControllerButtonIDDefinitions__NewEnumerator11 = 11,
	ControllerButtonIDDefinitions__NewEnumerator12 = 12,
	ControllerButtonIDDefinitions__NewEnumerator13 = 13,
	ControllerButtonIDDefinitions__NewEnumerator14 = 14,
	ControllerButtonIDDefinitions__NewEnumerator15 = 15,
	ControllerButtonIDDefinitions__NewEnumerator16 = 16,
	ControllerButtonIDDefinitions__NewEnumerator17 = 17,
	ControllerButtonIDDefinitions__NewEnumerator18 = 18,
	ControllerButtonIDDefinitions__NewEnumerator19 = 19,
	ControllerButtonIDDefinitions__NewEnumerator20 = 20,
	ControllerButtonIDDefinitions__NewEnumerator21 = 21,
	ControllerButtonIDDefinitions__ControllerButtonIDDefinitions_MAX = 22,

};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
